function [Aht]=function_viscosity(nx, nz, situ_temp, T_liq, T_sol, Ah_liq, Ah_sol)
nxz = nx*nz;
Aht=zeros(nxz,1);
    num = 1; Number=zeros(nz,nx);
    for i=1:nz
      for j=1:nx
          Number(i,j)=num;
          num=num+1;
      end
    end
    
        for i=1:nz
            for j=1:nx
                ii = Number(i,j);
                a=5.3;    %tanh(a)=1;
                b=atanh(Ah_liq/Ah_sol);
                if situ_temp(ii)>=T_liq
                    Aht(ii,1)=Ah_liq*exp(-10/situ_temp(ii)*(situ_temp(ii)-T_liq));
                elseif situ_temp(ii)< T_sol
                    Aht(ii,1)=Ah_sol*exp(-0.5/situ_temp(ii)*(situ_temp(ii)-T_sol));
                elseif (T_sol<=situ_temp(ii)) && (situ_temp(ii)<T_liq)
                    Aht(ii,1)=Ah_sol*tanh(a-(a-b)*(situ_temp(ii)-T_sol)/(T_liq-T_sol));
                end
            end
        end




end