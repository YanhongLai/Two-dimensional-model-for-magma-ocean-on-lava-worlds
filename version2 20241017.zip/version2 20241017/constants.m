  %Set Constant Parameters

  %timestep parameters
  t0=0; 
  dt = 2000;     
  tend = 2E3;
  dt_output=1E4;

  % silicate parameters
  T_liq = 2000;    
  T_sol = 1700;
  alpha = 2E-4; 
  cp = 1800; 
  g = 22;
  deltarho=0.1;

  %oceanic parameters
  kappa = 1E3;  
  kh = 1E3;    
  kz = 1E-4;   
  kh_GM = 1E3;
  kz_convec = 1E1;
  
  Ah_liq = 1E4;   
  Ah_sol = 1E8; 
  Az_liq = 1E2;    
  Az_sol = 1E8; 
  
% external forcing parameters
 Tsurf = 3000;   
 Tbot = 50; 
  tau = 10*86400;
  bottomDragLinear = 1E3;

