clc;clear;

% not output to nc files when simple test
output=false;   

% load constants parameters
run('constants.m');

  %%%%Initial values
     % path1='Snapshot20000000.nc';
     % t0=200E5; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Set grids and resolutions

  nx = 101;
  x1 = -18000000.0; x2 = 18000000.0;
  dx = ( x2 - x1 ) / ( nx - 1 );
  x = ( linspace ( x1, x2, nx ) )';
  xa=x./x2*110;
  x22=x2/110*90;
  
  %%%%%%%%%------------5 km deep-------vertical-----
  delRc= [40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 40,...
    40, 40, 40, 40, 40, 60, 60, 60, 60, 60, 100, 100, 100, 200, 200, 300, 300, 300, 300, 400, 400, 400, 400];

  delRc=-delRc;
  nz1=max(size(delRc));
  nz=nz1+1;
  z=zeros(nz,1);
for i=2:nz
    z(i)=z(i-1)+delRc(i-1);
end
% H1=sum(delRc);

nxz=nx*nz;
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Initialization
    % Setup numbering
  num = 1; Number=zeros(nz,nx);
  for i=1:nz
      for j=1:nx
          Number(i,j)=num;
          num=num+1;
      end
  end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%Determine the initial state
 


 Tbot2=T_liq;
  Tvert = zeros ( nz, 1);Tx = zeros ( nx, 1);
 for i=1:nz
     Tvert(i)=Tsurf-((Tsurf-Tbot2)/(nz-1))*(i-1); 
 end
%  for j=1:nx
%      Tx(j)=Tbot+((Tsurf-Tbot)*cos((abs(x(j))/x2)*pi/2)); 
%  end

Tx=function_forcingTs(nx, xa, x, x22, Tsurf, Tbot);

 taux=zeros(nx,1); 
 tau0=0.0;
  % fid=fopen('taux_nx101_Kepler-10b_CD1E-2.bin','rb');
  % taux = fread(fid,[nx 1],'double');
  % fclose(fid);

T0 = zeros ( nx*nz, 1 );  
for i=1:nz
    for j=1:nx
        ii = Number(i,j);
        if Tx(j)>T_sol
            T0(ii)=T_sol;
        else
            T0(ii)=Tx(j);
        end
     end
end
  
 T2=T0;  u2=zeros(nxz,1);    w2=zeros(nxz,1);
 eta2=zeros(nx,1);
 kh2=zeros(nxz,1);     kh2(:,1)=kh;
 kz2=zeros(nxz,1);     kz2(:,1)=kz;
 
  
 if t0~=0
    u21=ncread(path1,'u');  w21=ncread(path1,'w');
    T21=ncread(path1,'T');  eta21=ncread(path1,'eta');    
    for i=1:nz
        for j=1:nx
            ii=Number(i,j);
            u2(ii,1)=u21(i,j);  
            w2(ii,1)=w21(i,j);
            T2(ii,1)=T21(i,j);  
        end
    end
    
    eta2(:)=eta21(:); 
 end

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %Start calculating
ut1=u2; wt1=w2; etat=eta2;
tt=1;
 for k=(t0):tend
        Tt1=T2;  %%potential temperature
        kht=kh2; kzt=kz2;
        
        %%%% conversion from potential temp. to in situ temp.
        [situ_temp]=function_theta2temp(nx, nz, delRc, alpha, cp, g, Tt1);
        
        [rho2] = function_SilicatesDensity( nx, nz, z, T_sol, T_liq, g, situ_temp, deltarho);
        rho1t=rho2;
        rhos=zeros(nx,1);   rhos(1:end)=rho2(1:nx,1);  
        
        pres2=zeros(nxz,1);     %values of the last timestep using the density of last timestep
        p1=zeros(nx,1);   p2=zeros(nx,1);
        for i=1:nz
            for j=1:nx
                ii=Number(i,j);
                if i==1
                    p1(j)=rhos(j)*g*etat(j,1); p2(j)=rhos(j)*g*etat(j,1)+abs(rho2(ii)*g*0.5*delRc(i));
                else
                    p1(j)=p2(j);
                    p2(j)=p2(j)+abs(rho2(ii)*g*delRc(i-1));
                end
                pres2(ii)=0.5*(p1(j)+p2(j));                
            end
        end
        pres1t=pres2; 
        
        %%%%%%%%%%%%%%%%%%%%%%%
        % Visocisty, using the temp. of the last timestep
        Aht=function_viscosity(nx, nz, situ_temp, T_liq, T_sol, Ah_liq, Ah_sol);
        Azt=function_viscosity(nx, nz, situ_temp, T_liq, T_sol, Az_liq, Az_sol);
       
        %%%%%%%%%%%%%%%%%%%%%%%% momentum equation loop
        [u2] = AdvectionDiffusion2Dforu_delR( nx, nz, dt, dx, delRc, Aht, Azt, ut1, wt1, pres1t, rho1t, taux, bottomDragLinear);
        % [u2] = function_ADV4U( nx, nz, dt, dx, delRc, Aht, Azt, ut1, wt1, pres1t, rho1t, taux, bottomDragLinear);

        u4=zeros(nz,nx);            % 1D to 2D
        for i=1:nz
            for j=1:nx
                 ii=Number(i,j);
                 u4(i,j)=u2(ii,1);
            end
        end
        
        eta2=function_solveSSH(nx, nz, dt, dx, delRc, u2, etat);
        w4=function_solvew(nx, nz, z, dt, dx, u4, etat, eta2);
                
        %2D to 1D
         for i=1:nz
             for j=1:nx
                ii = Number(i,j);
                w2(ii,1) = w4(i,j);
             end
         end
         
         ut1 = u2; wt1 = w2; etat = eta2;
       
       %%%%%%%%%%Gent-McWilliams parameterization
       pot_rho=function_PotentiaDensity(nx, nz, T_sol, T_liq, Tt1, deltarho);       
       for i=2:nz
           for j=1:nx
               ii=Number(i,j);
               ii1=Number(i-1,j); 
               if pot_rho(ii)<pot_rho(ii1)
                   kzt(ii1)=kz_convec;
               end
           end
       end
       
        %%%%%%%%%%%%%%%%%%%%%% thermodynamic equation
        [T2] = AdvectionDiffusion2DforT_delR( nx, nz, dt, dx, delRc, kht, kzt, Tx, ut1, wt1, Tt1,tau);
        T4=zeros(nz,nx);            % 1D to 2D
        for i=1:nz
            for j=1:nx
                 ii=Number(i,j);
                 T4(i,j)=T2(ii,1);
            end
        end

        kh4=zeros(nz,nx);   kz4=zeros(nz,nx);
        Ah4=zeros(nz,nx);   Az4=zeros(nz,nx);
        rho4=zeros(nz,nx);  pres4=zeros(nz,nx);
        pot_rho4=zeros(nz,nx);
        situ_temp4=zeros(nz,nx);
        
        for i=1:nz
            for j=1:nx
                 ii=Number(i,j);
                 kh4(i,j)=kht(ii,1);    %values of the last time step
                 kz4(i,j)=kzt(ii,1);
                 Ah4(i,j)=Aht(ii,1);
                 Az4(i,j)=Azt(ii,1);
                 
                 rho4(i,j)=rho2(ii,1);
                 pres4(i,j)=pres2(ii,1);
                 pot_rho4(i,j)=pot_rho(ii,1);
                 
                 situ_temp4(i,j)=situ_temp(ii);
            end
        end
        
        
       %%%%%%%%%%%%%%%%%Output many times
       if output    % output or not
         if rem(k,dt_output)==0
             path=['nc output/Snapshot', sprintf('%08d', k), '.nc'];
             nccreate(path,'u','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'T','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'w','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'rho','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'pot_rho','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'pres','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'Ah','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'Az','Dimensions', {'z',nz,'x',nx},'FillValue','disable');
             nccreate(path,'eta','Dimensions', {'x',nx},'FillValue','disable');
             nccreate(path,'x','Dimensions',{'x',nx});
             nccreate(path,'z','Dimensions',{'z',nz});
             nccreate(path,'ST','Dimensions', {'z',nz,'x',nx},'FillValue','disable');

             ncwrite(path,'x',x);    ncwrite(path,'z',z);
             ncwrite(path,'u',u4);   ncwrite(path,'T',T4);  ncwrite(path,'w',w4);
             ncwrite(path,'rho',rho4);  ncwrite(path,'pres',pres4);
             ncwrite(path,'pot_rho',pot_rho4);
             ncwrite(path,'Ah',Ah4);    ncwrite(path,'Az',Az4);
             ncwrite(path,'eta',eta2);
             ncwrite(path,'ST',situ_temp4);
         end
       end

 end
  
 if true
     figure;
     subplot(2,3,1);
     contourf(xa,z,u4,'LineStyle','none'); hold on;
     colorbar;

     subplot(2,3,2);
     contourf(xa,z,T4,'LineStyle','none'); hold on;
     colorbar;

     subplot(2,3,3);
     contourf(xa,z,w4,'LineStyle','none'); hold on;
     colorbar;

     subplot(2,3,4);
     plot(xa, u4(1,:),'b-','Linewidth',3); hold on;

     subplot(2,3,5);
     plot(xa, T4(1,:),'b-','Linewidth',3); hold on;

     subplot(2,3,6);
     plot(xa, eta2,'b-','Linewidth',3); hold on;

 end

