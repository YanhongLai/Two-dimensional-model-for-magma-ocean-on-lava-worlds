function w4=function_solvew(nx, nz, z, dt, dx, u4, etat, eta2)
        w4=zeros(nz,nx);
        for i=1:nz
            for j=1:nx 
                if i==nz
                    w4(i,j)=0;
                elseif i==1
                    w4(1,j)=(eta2(j,1)-etat(j,1))/dt;  
                elseif j==1 
                    w4(i,j)=w4(i-1,j)-(z(i)-z(i-1))/2/dx*(u4(i,j+1)-u4(i,nx-1));
                elseif j==nx
                    w4(i,j)=w4(i-1,j)-(z(i)-z(i-1))/2/dx*(u4(i,2)-u4(i,j-1));   
                else
                    w4(i,j)=w4(i-1,j)-(z(i)-z(i-1))/2/dx*(u4(i,j+1)-u4(i,j-1));   
                end
            end
        end



end