function eta2=function_solveSSH(nx, nz, dt, dx, delRc, u2, etat)

  num = 1; Number=zeros(nz,nx);
  for i=1:nz
      for j=1:nx
          Number(i,j)=num;
          num=num+1;
      end
  end

  eta2=zeros(nx,1);
  
        hdiv_inter=zeros(nx,1);
        for j=1:nx
            for i=2:nz
                ii=Number(i,j);
                if j==1
                    ii2=Number(i,nx-1);
                    hdiv_inter(j)=hdiv_inter(j)-dt/2/dx*(u2(ii+1,1)-u2(ii2,1))*delRc(i-1);
                elseif j==nx
                    ii2=Number(i,2);
                    hdiv_inter(j)=hdiv_inter(j)-dt/2/dx*(u2(ii2,1)-u2(ii-1,1))*delRc(i-1);
                else
                    hdiv_inter(j)=hdiv_inter(j)-dt/2/dx*(u2(ii+1,1)-u2(ii-1,1))*delRc(i-1);
                end
            end
            
            eta2(j,1)=etat(j,1) - hdiv_inter(j);
        end

end