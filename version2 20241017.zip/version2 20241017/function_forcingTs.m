function [Tx]=function_forcingTs(nx, xa, x, x22, Tsurf, Tbot)
   
Tx = zeros(nx,1);

  for j=1:nx
     if xa(j)>=-85
         Tc = Tbot+((Tsurf-Tbot)*((cos((abs(x(j))/x22)*pi/2)^(1/4))));
         xc = x(j);
         xac = xa(j);
         break;
     end
  end    

   for j=1:nx
     if -85<=xa(j) && xa(j)<=85
         Tx(j) = Tbot+((Tsurf-Tbot)*((cos((abs(x(j))/x22)*pi/2)^(1/4))));
     elseif xa(j)>=110 || xa(j)<=-110
        Tx(j) = Tbot;
     elseif xa(j)>85 && xa(j)<110
        Tx(j) = Tbot+(Tc-Tbot)/(-xac-110)*(xa(j)-110);
     elseif xa(j)>-110 && xa(j)<-85
        Tx(j) = Tbot+(Tc-Tbot)/(xac+110)*(xa(j)+110);
     end     
   end

end
